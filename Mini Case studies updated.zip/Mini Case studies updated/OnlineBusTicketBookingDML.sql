d   OnlineTicketBookingDML.sql C:\Users\448682\Desktop\OnlineTicketBookingDML.sql    >   C:\Users\448682\AppData\Local\Temp\OnlineTicketBookingDML.sql �  


INSERT INTO Travel_agency(travel_agency_id, travel_agency_name, address, location, contact_number, email_id) VALUES
('T01','Zucca','Hablis hotel','Guindy',9876543210,'kpnagency@gmail.com');

COMMIT;


INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B01','Ac Sleeper','T01',34);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B02','NonAc Sleeper','T01',30);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B03','Ac SemiSleeper','T01',28);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B04','NonAc Semi Sleeper','T01',30);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B05','Ac Sleeper','T01',30);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B06','Ac SemiSleeper','T01',30);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B07','NonAc Semi Sleeper','T01',32);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B08','NonAc Sleeper','T01',34);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B09','Ac Semi Sleeper','T01',31);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B10','NonAc Semi Sleeper','T01',35);
INSERT INTO bus_details(bus_id, bus_category, travel_agency_id, number_of_seats) VALUES
('B11','Ac Sleeper','T01',32);
COMMIT;


INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place, departure_time)
VALUES('P01','R01','B02','20-May-2016','Madurai','Chennai','20:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P02','R02','B03','23-June-2016','Coimbatore','Chennai','22:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P03','R03','B01','22-May-2016','Chennai','Bangalore','19:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P04','R04','B04','19-May-2016','Chennai','Hyderabad','18:30 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P05','R05','B05','23-May-2016','Chennai','Madurai','17:30 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P06','R06','B06','19-Aug-2016','Chennai','Hyderabad','22:30 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P07','R01','B07','29-Sep-2016','Chennai','Bangalore','20:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P08','R02','B08','13-Aug-2016','Coimbatore','Chennai','21:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P09','R03','B09','22-Dec-2016','Chennai','Mumbai','18:00 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P10','R04','B10','26-Nov-2016','Chennai','Trichy','23:30 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P11','R05','B11','23-Sep-2016','Chennai','Hyderabad','22:45 PM');
INSERT INTO Travel_plan(Travel_plan_number,Route_number,Bus_id,Date_of_journey,Source_place,Destination_place,Departure_time)
VALUES('P12','R06','B07','20-Aug-2016','Chennai','Madurai','18:50 PM');

COMMIT;

INSERT INTO Customer_Details(booking_customer_id, booking_customer_name, customer_mobile_number, customer_email_id)
VALUES('C001','Abinaya',9876543021,'abinaya12@gmail.com');
INSERT INTO Customer_Details(booking_customer_id, booking_customer_name, customer_mobile_number, customer_email_id)
VALUES('C002','Bala',9943881856,'balavick@gmail.com');
INSERT INTO Customer_Details(booking_customer_id, booking_customer_name, customer_mobile_number, customer_email_id)
VALUES('C003','Ashish',9998886342,'ashley23@gmail.com');
INSERT INTO Customer_Details(booking_customer_id, booking_customer_name, customer_mobile_number, customer_email_id)
VALUES('C004','Sakthi',8956734567,'sakthi32@gmail.com');

COMMIT;


INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK01','P01','C001');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK02','P04','C004');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK03','P03','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK04','P02','C001');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK05','P05','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK06','P06','C003');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK07','P07','C001');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK08','P08','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK09','P09','C003');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK10','P10','C004');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK11','P01','C004');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK12','P02','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK13','P03','C003');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK14','P05','C001');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK15','P01','C004');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK16','P01','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK17','P04','C003');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK18','P04','C002');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK19','P01','C001');
INSERT INTO Booking_master(booking_id,travel_plan_number,booking_customer_id) VALUES
('BK20','P01','C001');
COMMIT;


INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('U1','BK01','Latha',34,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('R1','BK02','Suganya',23,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('L2','BK01','Gayathri',24,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('R4','BK02','Sowmya',28,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('L4','BK03','Gavin',25,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('U5','BK04','Surendar',25,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('U6','BK05','Hari',27,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('L13','BK06','Harshini',30,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('u8','BK07','narmatha',30,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('L20','BK08','ramya',23,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('s14','BK09','surya',24,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('r20','BK10','Aaron',30,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('f15','BK11','shruthi',20,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('u2','BK12','Rama',30,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('l6','BK13','usha',31,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('b7','BK14','Keerthana',25,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('a8','BK15','Meena',44,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('d9','BK16','Divya',36,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('r10','BK17','Gopi',36,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('s13','BK18','Pradeep',40,'M');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('t23','BK19','Jayashree',39,'F');
INSERT INTO booking_details(Seat_number,Booking_id,Passenger_name,Passenger_age,Passenger_gender) VALUES
('U19','BK20','Gokul',31,'M');

COMMIT;