INSERT INTO Train_details(Train_number,Train_name,From_place,To_place,Distance) 
VALUES(2677,'Ernakulam EXP','Bangalore','Coimbatore','0377KM');
INSERT INTO Train_details(Train_number,Train_name,From_place,To_place,Distance) 
VALUES(16127,'MS Guruvayur EXP','Chennai','Madurai','472KM');
INSERT INTO Train_details(Train_number,Train_name,From_place,To_place,Distance) 
VALUES(12635,'VAIGAI EXP','Madurai','Chennai','472KM');
INSERT INTO Train_details(Train_number,Train_name,From_place,To_place,Distance) 
VALUES(12007,'SHATABDI EXP','Chennai','Bangalore','348KM');

COMMIT;


INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(4118359115,'20-Jun-2016','3A','25-May-2016','Bangalore CANT(BNC)',600,2677);
INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(5229459116,'01-Jul-2016','1A','30-May-2016','Bangalore CANT(BNC)',800,2677);
INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(6339458227,'03-Jun-2016','2A','12-May-2016','Bangalore Cy Jn(SBC)',700,2677);
INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(6789345901,'22-Jul-2016','2A','14-May-2016','Tamabaram',800,12007);
INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(1239336812,'22-Oct-2016','2A','04-Jan-2016','Central',800,12635);
INSERT INTO Ticket_master(PNR_number,Date_of_journey,Class,Date_of_booking,Boarding_place,Total_fare,Train_number) VALUES
(8751228734,'22-Oct-2016','3A','14-Feb-2016','Central',800,16127);

COMMIT;




INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(4118359115,'B1',10,'Ambika','F',23,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(5229459116,'A1',30,'Bala','M',24,'Waiting');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(6339458227,'A5',24,'Abi','F',23,'Waiting');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(4118359115,'B1',12,'Keerthi','F',23,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(5229459116,'A2',01,'Prakash','M',35,'Waiting');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(8751228734,'S2',31,'Raghu','M',35,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(1239336812,'S1',12,'Vinoth','M',32,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(6789345901,'S3',15,'Adithya','M',31,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(6789345901,'S1',12,'Gavin','M',32,'Confirm');
INSERT INTO Ticket_details(PNR_number,Coach_number,Seat_number,Passenger_name,gender,Passenger_age,Booking_status)
VALUES(6789345901,'S2',11,'Suren','M',31,'Confirm');


COMMIT;