
DROP TABLE Ticket_details;

DROP TABLE  Ticket_master;

DROP TABLE  Train_details;



CREATE TABLE Train_details(
                            Train_number NUMBER(10) primary key,
                            Train_name varchar2(20),
                            From_place varchar2(30),
                            To_place varchar2(30),
                            Distance VARCHAR2(20)
                            );


CREATE TABLE Ticket_master(
                            PNR_number NUMBER(15) primary key,
                            Date_of_journey date,
                            Class varchar2(10),
                            Date_of_booking date,
                            Boarding_place varchar2(30),
                            Total_fare number(10), 
                            Train_number NUMBER(10),
                            CONSTRAINT FKTicketMaster FOREIGN KEY(Train_number) REFERENCES Train_details(Train_number)
                            );


CREATE TABLE Ticket_details(
                              PNR_number NUMBER(15),
                              Coach_number varchar2(10),
                              Seat_number NUMBER(10),
                              passenger_age NUMBER(10),
                              Passenger_name varchar2(30),
                              gender varchar2(10),
                              Booking_status varchar2(20),
                              CONSTRAINT pkticketdetails PRIMARY KEY(PNR_number,Coach_number,Seat_number),
                              CONSTRAINT FKticektdetails FOREIGN KEY(PNR_number) REFERENCES Ticket_master(PNR_number)
                              );