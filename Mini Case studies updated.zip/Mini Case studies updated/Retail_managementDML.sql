INSERT INTO Shop(shopid, shopname, contactno, address,website) VALUES
('SH01','Kannan Stores',9876054321,'Guindy','kannanstores@co.in');


COMMIT;

INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C01','Meena','Vadapalani',8901234567,'SH01');
INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C02','Ravi','guindy',7723490567,'SH01');
INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C03','Latha','Thoraipakkam',8899675432,'SH01');
INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C04','Soundarya','Tnagar',8903451234,'SH01');
INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C05','Rama','mettukuppam',7895643210,'SH01');
INSERT INTO Retail_Customers(customerid, customername, address, contactno, shopid) 
VALUES('C06','Sridhar','Porur',9980776540,'SH01');

COMMIT;

INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT01','Samsung');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT02','Moto');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT03','HTC');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT04','Lenova');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT05','Dell');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT06','HP');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT07','Lenova Lap');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT08','LG chormebase');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT09','Acer Aspire Z1');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT10','Asus ET2040IUK');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT11','Micromax Canvas tab');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT12','iball Q40i');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT13','Samsung Galaxy');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT14','Sennheiser');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT15','Audio technica');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT16','Hard disk');
INSERT INTO category_details(categoryid, categorydesc) VALUES
('CT17','Keyboard');

COMMIT;


INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P01','Mobiles','CT01',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P02','Mobiles','CT02',100,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P03','Mobiles','CT03',30,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P04','Mobiles','CT04',50,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P05','Tab','CT13',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P06','Tab','CT12',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P07','Tab','CT11',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P08','Desktop','CT10',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P09','Desktop','CT09',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P10','Desktop','CT08',10,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P11','Laptop','CT05',50,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P12','Laptop','CT06',60,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P13','Laptop','CT07',100,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P14','Headphones','CT14',200,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P15','Headphones','CT15',300,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P16','Computer Accessories','CT16',18,'SH01');
INSERT INTO Product(productid, name, category_id, qtyavailable, shopid) VALUES
('P17','Computer Accessories','CT17',0,'SH01');

COMMIT;



INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD1','26-May-2016',5000,'C01');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD2','26-May-2016',7000,'C01');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD3','26-May-2016',6000,'C01');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD4','11-Apr-2016',5000,'C02');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD5','15-Apr-2016',9000,'C02');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD6','26-Apr-2016',9000,'C02');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD7','22-May-2016',10000,'C03');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD8','20-May-2016',4500,'C03');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD9','26-May-2016',4000,'C04');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD10','15-Mar-2016',35000,'C05');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD11','11-Jan-2016',30000,'C05');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD12','10-Feb-2016',40000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD13','18-Apr-2016',50000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD14','18-Apr-2016',35000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD15','28-May-2016',50000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD16','29-Apr-2016',2000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD17','30-May-2016',3000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD18','12-Jan-2016',4000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD19','1-Apr-2016',2000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD20','18-MAr-2016',2000,'C06');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD21','12-Feb-2016',5000,'C05');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD22','16-Jan-2016',4500,'C04');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD23','19-Apr-2016',5000,'C03');
INSERT INTO Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD24','20-May-2016',5000,'C02');
INSERT INTO  Order_master(orderno, dateoforder, ordervalue, custid) VALUES
('OD25','22-Apr-2016',100000,'C01');

COMMIT;



INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD1','P01',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD1','P11',1,6000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD2','P01',1,7000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD2','P02',1,17000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD2','P03',1,700);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD3','P12',1,3000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD3','P01',1,6000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD4','P02',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD4','P12',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD5','P03',2,4500);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD6','P04',1,9000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD7','P05',2,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD8','P06',1,4500);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD9','P07',2,2000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD10','P08',1,35000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD11','P09',1,30000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD12','P10',1,40000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD13','P11',1,50000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD14','P12',1,35000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD15','P13',1,50000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD16','P14',2,1000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD17','P15',3,1000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD18','P16',2,2000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD19','P17',2,1000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD20','P17',1,2000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD21','P03',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD22','P02',1,4500);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD23','P05',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD24','P01',1,5000);
INSERT INTO Order_Details(orderid, productid, qtypurchased, productprice) VALUES
('OD25','P11',2,50000);

COMMIT;