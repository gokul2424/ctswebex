DROP TABLE Order_Details;

DROP TABLE Order_master;

DROP TABLE Product;

DROP TABLE Category_details;

DROP TABLE Retail_Customers;

DROP TABLE Shop;




CREATE TABLE Shop(
                  ShopId varchar2(20) PRIMARY KEY,
                  ShopName varchar2(20),
                  ContactNo NUMBER(10),
                  Address varchar2(30),
                  Website varchar2(30)
                  );

CREATE TABLE Retail_Customers(
                        CustomerId varchar2(20) PRIMARY KEY,
                        CustomerName varchar2(20),
                        Address varchar2(30),
                        ContactNo NUMBER(10),
                        ShopId varchar2(20),
                        CONSTRAINT Retail_Customers_FK FOREIGN KEY(ShopId) REFERENCES Shop(ShopId)
                        );

CREATE TABLE Category_details(
                    CategoryID varchar2(20) PRIMARY KEY,
                    CategoryDesc varchar2(20)
                    );


CREATE TABLE Product(
                    ProductId varchar2(20) PRIMARY KEY,
                    Name varchar2(20),
                    qtyAvailable NUMBER(10),
                    Category_id varchar2(20),
                    ShopId varchar2(20),
                    CONSTRAINT product FOREIGN KEY(ShopId) REFERENCES Shop(ShopId),
                    CONSTRAINT FKProductCategoryId FOREIGN KEY(Category_id) REFERENCES Category_details(CategoryID)
                    );

CREATE TABLE Order_master(
                  Orderno varchar2(20) PRIMARY KEY,
                  DateOfOrder date,
                  Ordervalue Number(10),
                  CustId varchar2(20),
                  CONSTRAINT FK1ORdermasterCustId FOREIGN KEY(CustId) REFERENCES Retail_Customers(CustomerId)
                  );


CREATE TABLE Order_Details(
                      OrderId varchar2(20),
                      ProductID varchar2(20),
                      qtypurchased NUMBER(10),
                      ProductPrice Number(10),
                      CONSTRAINT PKOrder_detail PRIMARY KEY(OrderID,ProductID),
                      CONSTRAINT FK1Order_DetailOrderno FOREIGN KEY(OrderId) REFERENCES Order_master(Orderno),
                      CONSTRAINT FK2Order_Detail2ProductId FOREIGN KEY(ProductID) REFERENCES Product(ProductId)
                      );


