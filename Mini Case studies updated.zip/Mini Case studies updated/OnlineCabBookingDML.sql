

insert into Company(company_id,name,address,contactno,emailid,website) values
('C1','Yura Taxi','Alandur',04466666666,'queriesntc@gmail.com','www.ntctaxi.com');



insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T01','Sedan','TN22CK2055','20-May-2000','C1');
insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T02','Basic','TN22CK2060','20-May-2001','C1');
insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T03','Premium','TN30PR2003','11-Apr-2000','C1');
insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T04','Indica','TN30PR2010','20-Jul-2000','C1');
insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T05','Sumo','TN26KP2006','20-Jul-2005','C1');
insert into Taxi(taxiid, taxidesc, vehicleno, yearofpurchase, company_id) values
('T06','Sedan','TN26KP2040','20-Aug-2006','C1');

COMMIT;

insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D01','Muthaaiya','Tambaram',9875640231,'TN59 34567890','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D02','Ram','Alandur',8876905432,'TN55 10293847','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D03','Murali','Guindy',7794590234,'TN67 57483920','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D04','Naveen','Vadapalani',9654784600,'TN60 34567568','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D05','Harish','Porur',9918564438,'TN12 97023890','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D06','Vinoth','Tnagar',9943881856,'TN12 12345678','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D07','Venkatesh','Royapet',8939995750,'TN34 87654321','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D08','Vignesh','Guindy',8957504890,'TN21 19283746','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D09','Arul','Periyar',9876540231,'TN16 26384759','C1');
insert into Driver(driverid, name, address, contactno, licenseno, company_id) values
('D10','Harith','Simmakal',9000456789,'TN19 99375813','C1');

COMMIT;

insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C01','Abinaya',9876543021,'Tharamani','abinaya123@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C02','Gavin',8956734567,'Karapakkam','gavinforegmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C03','Bala',9998886342,'Medavakkam','balamass@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C04','Suren',9500404787,'Tnagar','suren123@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C05','Ganesh',962962803,'Thoraipakkam','ganesh3@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C06','Sunder',9952415786,'Tambaram','sunderrock@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C07','Kala',9600547832,'Perungulathur','kala123@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C08','Kanitha',8801345622,'Annanagar','kanisweet@gmail.com','C1');
insert into Customers_details(customerid, name, contactno, address, emailid, company_id) values
('C09','Priya',8945997712,'Simmakal','Priya12@gmail.com','C1');
COMMIT;


insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T02','D03','26-May-2016','Waiting');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T01','D01','25-May-2016','Waiting');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T01','D02','20-April-2016','Confirmed');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T02','D04','12-April-2016','Confirmed');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T03','D07','27-May-2016','Waiting');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T04','D08','10-March-2016','Confirmed');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T05','D09','26-Feb-2016','Confirmed');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T06','D10','26-May-2016','Waiting');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T04','D10','10-June-2016','Waiting');
insert into driverallocation(taxiid, driverid, dateofallocation,status) values
('T02','D08','11-May-2016','Confirmed');
COMMIT;

insert into Trip(
trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) 
values('TP1','D03','T02','C01','26-May-2016 10pm','Tharamani','Guindy','4 KM',150);

insert into Trip(
trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) 
values('TP2','D01','T01','C02','25-May-2016 08PM','Karapakkam','TNagar','18 KM',450);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP3','D02','T01','C03','20-April-2016 07PM','Medavakkam','Vadapalani','18 KM',500);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP4','D04','T02','C04','12-April-2016 06PM','Tnagar','Tambaram','16 KM',350);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP5','D07','T03','C05','27-May-2016 05PM','Thoraipakkam','Tambaram','20 KM',500);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP6','D08','T04','C06','10-March-2016 07PM','Tambaram','Tnagar','16 KM',350);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP7','D09','T05','C08','26-Feb-2016 09PM','Annanagar','Simmakal','10 KM',250);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP8','D10','T06','C09','26-May-2016 11PM','Simmakal','Periyar','14 KM',300);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP9','D08','T03','C07','27-May-2016 10PM','Tamabaram','Tnagar','16 KM',350);

insert into Trip(trip_no, driverid, taxiid, customerid, datetimeoftrip, fromplace, toplace, kilometertravelled, amountpaid) values('TP10','D01','T04','C01','10-June-2016 05PM','Vadapalani','Tharamani','20 KM',650);

COMMIT;