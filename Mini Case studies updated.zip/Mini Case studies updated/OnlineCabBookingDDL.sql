DROP TABLE Trip;

DROP TABLE DriverAllocation;

DROP TABLE Customer_details;

DROP TABLE Driver;

DROP TABLE Taxi;

DROP TABLE Company;

CREATE TABLE Company(
			Company_id varchar2(20) primary key,
			Name varchar2(20),
			Address varchar2(30),
			ContactNo Number(12),
			EmailId varchar2(25),
			website varchar2(20)
		    );

CREATE TABLE Taxi(
			TaxiId varchar2(20) PRIMARY KEY,
			TaxiDesc varchar2(20),
			VehicleNo varchar2(30),
			YearOfPurchase date,
			Company_id varchar2(20),
			CONSTRAINT FKTAXI FOREIGN KEY(Company_id) REFERENCES Company(Company_id)
		);


CREATE TABLE Driver(
			DriverId varchar2(20) PRIMARY KEY,
			Name varchar2(25),
			Address varchar2(30),
			ContactNo Number(10),
			LicenseNo varchar2(30),
			Company_id varchar2(20),
			CONSTRAINT FKDriver FOREIGN KEY(Company_id) REFERENCES Company(Company_id)
		);

CREATE TABLE Customers_details(
					CustomerId varchar2(20) primary key,
					Name varchar2(20),
					ContactNo Number(10),
					Address varchar2(30),
					EmailId varchar2(20),
					Company_id varchar2(20),
					CONSTRAINT FKCustomer FOREIGN KEY(Company_id) REFERENCES Company(Company_id)
				);

CREATE TABLE DriverAllocation(
					TaxiID varchar2(20),
					DriverID varchar2(20),
					DateOfAllocation date,
					Status varchar2(20),
					CONSTRAINT PKDriver PRIMARY KEY(TaxiID,DriverID),
					CONSTRAINT FKDriverAllote FOREIGN KEY(TaxiID) REFERENCES Taxi (TaxiId),
					CONSTRAINT FKDriver2 FOREIGN KEY(DriverID) REFERENCES Driver(DriverId)
			);


create table Trip(
			Trip_no varchar2(20) PRIMARY KEY,
			DriverId varchar2(20),
			TaxiId Varchar2(20),
			CustomerId varchar2(20),
			DateTimeOfTrip varchar2(20),
			FromPlace varchar2(30),
			ToPlace varchar2(30),
			KilometerTravelled varchar2(20),
			AmountPaid number(20),
			CONSTRAINT FKTrip FOREIGN KEY(CustomerId) REFERENCES Customers_details(CustomerId),
			CONSTRAINT FKTrip2 FOREIGN KEY(TaxiID) REFERENCES Taxi(TaxiId),
			CONSTRAINT FKTrip3 FOREIGN KEY(DriverID) REFERENCES Driver(DriverId)
		);