�   OnlineTicketBookingDDL.sql C:\Users\448682\Desktop\OnlineTicketBookingDDL.sql    >   C:\Users\448682\AppData\Local\Temp\OnlineTicketBookingDDL.sql   

DROP TABLE Booking_details;

DROP TABLE Booking_master;

DROP TABLE Customer_details;

DROP TABLE Travel_plan;

DROP TABLE Bus_details;

DROP TABLE Travel_agency;



CREATE TABLE Travel_agency(
                    Travel_agency_id varchar2(20) primary key,
                    Travel_agency_name varchar2(20),
                    Address varchar2(20),
                    Location varchar2(20),
                    Contact_number Number(20),
                    Email_id varchar2(20)
                    );


CREATE TABLE Bus_details(
                          Bus_id varchar2(20) primary key,
                          Bus_category varchar2(25),
                          Travel_agency_id varchar2(20),
                          Number_of_seats Number(20),
                          CONSTRAINT fkbusdetail FOREIGN KEY(Travel_agency_id) REFERENCES Travel_agency(Travel_agency_id)
                          );


CREATE TABLE Travel_plan(
                          Travel_plan_number varchar2(20) primary key,
                          Route_number varchar2(5),
                          Bus_id varchar2(20),
                          Date_of_journey date,
                          Source_place varchar2(20),
                          Destination_place varchar2(20),
                          Departure_time varchar2(20), 
                          CONSTRAINT fktravelplan FOREIGN KEY(Bus_id) REFERENCES Bus_details(Bus_id)
                          );


CREATE TABLE Customer_details(
                                Booking_customer_id varchar2(20) primary key,
                                Booking_customer_name varchar2(20),
                                Customer_mobile_number number(10),
                                Customer_email_id varchar2(20)
                                );


CREATE TABLE Booking_master(
                            Booking_id varchar2(20) primary key,
                            Travel_plan_number varchar2(20),
                            Booking_customer_id varchar2(20),
                            CONSTRAINT FKbookingmaster FOREIGN KEY(Travel_plan_number) REFERENCES Travel_plan(Travel_plan_number), 
                            CONSTRAINT FKbooking FOREIGN KEY(Booking_customer_id) REFERENCES Customer_Details(Booking_customer_id)
                            );

CREATE TABLE Booking_details(
                              Seat_number varchar2(20),
                              Booking_id varchar2(20),
                              Passenger_name varchar2(20),
                              Passenger_age number(10),
                              Passenger_gender VARCHAR2(20),
                              CONSTRAINT PKbookingdetails PRIMARY KEY(Seat_number,Booking_id)
                              );